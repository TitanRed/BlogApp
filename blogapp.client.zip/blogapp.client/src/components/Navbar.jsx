import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem("token");
        setIsLoggedIn(!!token);
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        setIsLoggedIn(false);
        navigate("/login");
    };

    return (
        <nav style={styles.nav}>
            <div style={styles.logoSection}>
                <h2 style={styles.logo}>BlogApp</h2>
            </div>
            <div style={styles.links}>
                <Link to="/" style={styles.link}>Home</Link>
                {isLoggedIn && <Link to="/add" style={styles.link}>Add Blog</Link>}

                {!isLoggedIn && (
                    <>
                        <Link to="/login" style={{ ...styles.link, ...styles.loginLink }}>Login</Link>
                        <Link to="/register" style={{ ...styles.link, ...styles.loginLink }}>Register</Link>
                    </>
                )}

                {isLoggedIn && (
                    <button onClick={handleLogout} style={styles.logoutButton}>Logout</button>
                )}
            </div>
        </nav>
    );
};

const styles = {
    nav: {
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        zIndex: 1000,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        padding: "12px 24px",
        backgroundColor: "#282c34",
        color: "#fff",
        gap: "12px",
        boxSizing: "border-box",
    },
    logoSection: {
        flex: "1 1 auto",
    },
    logo: {
        margin: 0,
        fontSize: "1.5rem",
    },
    links: {
        display: "flex",
        gap: "16px",
        flex: "0 0 auto",
        alignItems: "center",
    },
    link: {
        color: "#61dafb",
        textDecoration: "none",
        fontSize: "1rem",
        fontWeight: "500",
    },
    loginLink: {
        fontWeight: "bold",
        color: "#61dafb",
    },
    logoutButton: {
        backgroundColor: "transparent",
        border: "none",
        color: "#61dafb",
        fontSize: "1rem",
        fontWeight: "500",
        cursor: "pointer",
    }
};

export default Navbar;
