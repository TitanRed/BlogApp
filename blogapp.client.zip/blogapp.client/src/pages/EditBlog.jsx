import React from "react";
import { useParams } from "react-router-dom";

const EditBlog = () => {
    const { id } = useParams();

    return (
        <div>
            <h2>Edit Blog Post</h2>
            <p>Editing blog post with ID: {id}</p>
        </div>
    );
};

export default EditBlog;
