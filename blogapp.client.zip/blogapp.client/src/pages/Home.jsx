import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const Home = () => {
    const [blogs, setBlogs] = useState([]);

    useEffect(() => {
        const fetchBlogs = async () => {
            try {
                const response = await fetch("/api/BlogPosts");
                if (!response.ok) throw new Error("Failed to load");
                const data = await response.json();
                setBlogs(data);
            } catch (err) {
                console.error("Failed to load blogs:", err);
            }
        };

        fetchBlogs();
    }, []);

    return (
        <div style={styles.wrapper}>
            <h2 style={styles.heading}>All Blog Posts</h2>
            <div style={styles.grid}>
                {blogs.map((blog) => (
                    <div key={blog.id} style={styles.card}>
                        <h3>{blog.title}</h3>
                        <p><strong>Author:</strong> {blog.author}</p>
                        <Link to={`/view/${blog.id}`}>Read More</Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

const styles = {
    wrapper: {
        width: "90vw",
        padding: "10px",
        boxSizing: "border-box",
    },
    heading: {
        marginBottom: "20px",
    },
    grid: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
        gap: "20px",
    },
    card: {
        backgroundColor: "#1f1f1f",
        color: "#fff",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "15px",
        boxSizing: "border-box",
        height: "100%",
    },
};

export default Home;
